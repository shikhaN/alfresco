package com.lti.idss.service.taxpayer.everification.doc.business.controller;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.idss.service.taxpayer.everification.doc.business.service.DocService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DocController {

	Logger logger = LoggerFactory.getLogger(DocController.class);

	@Autowired
	DocService docservice;

	@RequestMapping("/ping")
	public String hello() {
		logger.info("welcome ping");
		return "Hello Welcome!";
	}

	@PostMapping(value = "/UploadDocuments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> uploadAlfrescoDocuments() throws FileNotFoundException, SQLException {

		logger.info("*** Inside UploadDocuments Controller ***");

		String response = docservice.uploadDocuments();
		return ResponseEntity.ok(response);

	}

	@PostMapping(value = "/combineDocuments", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> zipcombineDocuments(@RequestBody String folders) {

		logger.info("*** Inside combineDocuments Controller ***");

		String response = docservice.zipSelectedDocuments(folders);
		return ResponseEntity.ok(response);

	}

}
